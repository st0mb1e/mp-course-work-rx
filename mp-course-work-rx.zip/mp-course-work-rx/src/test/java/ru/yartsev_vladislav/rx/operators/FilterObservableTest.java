package ru.yartsev_vladislav.rx.operators;

import org.junit.jupiter.api.Test;
import ru.yartsev_vladislav.rx.core.Observable;
import ru.yartsev_vladislav.rx.core.Observer;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FilterObservableTest {

    @Test
    void shouldFilterValuesCorrectly() {
        List<Integer> result = new ArrayList<>();

        Observable<Integer> source = Observable.from(1, 2, 3, 4, 5);

        new FilterObservable<>(source, x -> x % 2 == 0)
                .subscribe(new Observer<>() {
                    @Override
                    public void onNext(Integer item) {
                        result.add(item);
                    }

                    @Override
                    public void onError(Throwable t) {
                        fail("Should not error");
                    }

                    @Override
                    public void onComplete() {
                        // ok
                    }
                });

        assertEquals(List.of(2, 4), result);
    }

    @Test
    void shouldPassAllWhenPredicateAlwaysTrue() {
        List<Integer> result = new ArrayList<>();

        Observable<Integer> source = Observable.from(1, 2, 3);

        new FilterObservable<>(source, x -> true)
                .subscribe(new Observer<>() {
                    @Override
                    public void onNext(Integer item) {
                        result.add(item);
                    }

                    @Override
                    public void onError(Throwable t) {
                        fail();
                    }

                    @Override
                    public void onComplete() {
                    }
                });

        assertEquals(List.of(1, 2, 3), result);
    }

    @Test
    void shouldEmitNothingWhenPredicateAlwaysFalse() {
        List<Integer> result = new ArrayList<>();

        Observable<Integer> source = Observable.from(1, 2, 3);

        new FilterObservable<>(source, x -> false)
                .subscribe(new Observer<>() {
                    @Override
                    public void onNext(Integer item) {
                        result.add(item);
                    }

                    @Override
                    public void onError(Throwable t) {
                        fail();
                    }

                    @Override
                    public void onComplete() {
                    }
                });

        assertTrue(result.isEmpty());
    }

    @Test
    void shouldCallOnErrorWhenPredicateThrows() {
        Observable<Integer> source = Observable.from(1, 2, 3);

        List<String> events = new ArrayList<>();

        new FilterObservable<>(source, x -> {
            if (x == 2) throw new RuntimeException("boom");
            return true;
        }).subscribe(new Observer<>() {
            @Override
            public void onNext(Integer item) {
                events.add("next:" + item);
            }

            @Override
            public void onError(Throwable t) {
                events.add("error:" + t.getMessage());
            }

            @Override
            public void onComplete() {
                events.add("complete");
            }
        });

        assertTrue(events.contains("error:boom"));
        assertFalse(events.contains("complete"));
    }

    @Test
    void shouldNotEmitAfterError() {
        List<Integer> result = new ArrayList<>();

        Observable<Integer> source = Observable.from(1, 2, 3);

        new FilterObservable<>(source, x -> {
            if (x == 2) throw new RuntimeException("fail");
            return true;
        }).subscribe(new Observer<>() {
            @Override
            public void onNext(Integer item) {
                result.add(item);
            }

            @Override
            public void onError(Throwable t) {
                // ignore
            }

            @Override
            public void onComplete() {
                fail("Should not complete");
            }
        });

        assertEquals(List.of(1), result);
    }

    @Test
    void shouldCompleteNormally() {
        List<Integer> result = new ArrayList<>();
        boolean[] completed = { false };

        Observable<Integer> source = Observable.from(1, 2, 3);

        new FilterObservable<>(source, x -> x > 0)
                .subscribe(new Observer<>() {
                    @Override
                    public void onNext(Integer item) {
                        result.add(item);
                    }

                    @Override
                    public void onError(Throwable t) {
                        fail();
                    }

                    @Override
                    public void onComplete() {
                        completed[0] = true;
                    }
                });

        assertTrue(completed[0]);
        assertEquals(List.of(1, 2, 3), result);
    }
}